<html><head><title>LOGIN WEB SESSION</title>
<link rel="stylesheet" type="text/css" href="view/css/loginsession.css" />
<link rel="stylesheet" type="text/css" href="view/css/menu.css" />
</head>
<body>

<center>	
<div style='width:600px' id="menu">
<table align=center>
<tr>
     <td width='100' align=center><a href='index.php'>Login</a></td> 
     <td width='100' align=center><a href='index.php?choice=home'>Home</a></td>
     <td width='100' align=center><a href='index.php?choice=about'>About</a></td>
     <td width='100' align=center><a href='index.php?choice=contact'>Contact</a></td>
</tr>
</table>
</div>
</center>

<center>
<div style='text-align:left;width:600px'>
<h2>HOME WELCOME</h2> 

PAGE UNDER CONSTRUCTION<br />
</div>
</center>

</body>
</html>
